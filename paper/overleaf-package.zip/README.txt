Upload this ZIP to Overleaf and select main.tex. Use XeLaTeX. The source includes all tables, diagrams and references.
Author: Ezekiel Ologunde, Independent Researcher; ologunde@bu.edu. No corresponding-author designation.
Generic ACM manuscript, nonacm: no journal acceptance or submission is claimed.
Original work remains unlicensed. Research artifacts: https://github.com/ezekielologunde/attack-graph-evidence-quality
